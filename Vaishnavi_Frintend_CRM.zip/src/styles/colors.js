export const globalColor = {
  mainColor: "#5a52d6",
  color: "white",
};
